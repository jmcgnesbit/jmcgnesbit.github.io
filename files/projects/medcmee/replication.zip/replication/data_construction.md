# Data construction

## Game data

The game data was constructed using the following steps.

### PFR

First we get game data, and objective probabilities from [pro-football-reference.com](https://www.pro-football-reference.com/) (PFR). The objective probabilities are no longer available on the site, so we use internet wayback machine. Note that the probabilities are updated over time, so we use the first snapshot available on wayback machine.

* [game 1](https://web.archive.org/web/20140103084753/https://www.pro-football-reference.com/boxscores/201312290dal.htm), snapshot at Jan 3, 2014 08:47:53 (note there appears to be an earlier snapshot, but this is dated Oct 7, 2013, before the game is played).
* [game 2](https://web.archive.org/web/20140107230601/https://www.pro-football-reference.com/boxscores/201401040phi.htm), snapshot at Jan 9, 2014 00:12:52.

Specifically, we copy the "Full Play-By-Play" table, which can be converted to `csv`. These tables are saved as `input\pfr_game_1_orig.csv `and `input\pfr_game_2_orig.csv `.

To these play-by-play tables, we remove some extra rows that do not contain probabilities.  and append Andrew's hand recorded commercial times from the `calendar_time_adj` column in `input\and_game1.csv` and `_csv\and_game2.csv`. 

* Note: `game2.csv` contains a missing row. The last play of quarter 1, with description "Nick Foles sacked by Cameron Jordan for -11 yards", must have been accidently deleted. This means that Andrew's times are a row too short. When copying Andrew's time into new file, I correct this by adding an additional row in the correct location.

The modified PFR files are saved as `input\pfr_game_1_mod.csv `and `input\pfr_game_2_mod.csv `.

### Sportradar

The play doesn't contain game times. These are retrieved using the [sportrader](https://developer.sportradar.com/docs/read/american_football/NFL_v5#nfl-v5-api-map) `python` API. This is detailed in `gamedata_from_sportrader.py`. This file finds the relevant games and downloads json files. From these json files we extract the quarter, the wall clock, the game clock, and the description of events. These are saved in `output/cow_eag.csv` and `output/eag_sai.csv`.

### Generate data for Stata

We merge the game data with the data from the experiment in `scripts/r_clean.R`. This merges task data stored in `input/20140131 Experiment Data Revised.csv` with the data from Sportradar. We also merge subject level data from `input/subjects_mod.csv` (this has been anonymized). This script also produces the graphs.

### Stata Analysis

The econometric analysis is performed in Stata with the `doall.do` script. There is some redundant data construction at the start of this file.