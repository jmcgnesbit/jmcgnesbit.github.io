# -*- coding: utf-8 -*-
"""
Created on Mon Mar  2 16:21:45 2020

@author: jmcgn
"""

import os

import pandas as pd
from sportradar import NFL #https://github.com/johnwmillr/SportradarAPIs
my_api = None #generate your own api key!

# My API key
nfl =  NFL.NFL(my_api)

# Find NFL game_id's
# First eagles cowboys
week_17 = nfl.get_weekly_schedule(2013, 'REG', 17).json()
week_17['week']['games']

for game in week_17['week']['games']:
    if game['home']['name'] == 'Dallas Cowboys':
        cow_eag_id = game['id']
        break
    
cow_eag_json = nfl.get_play_by_play(cow_eag_id).json()

# Then eag saints
wc = nfl.get_weekly_schedule(2013, 'PST', 1).json()
for game in wc['week']['games']:
    if game['home']['name'] == 'Philadelphia Eagles':
        eag_sai_id = game['id']
        break
    
eag_sai_json = nfl.get_play_by_play(eag_sai_id).json()


def json_to_df(json):
    event = []
    for quarter in json['periods']:
        for drive in quarter['pbp']:
            if 'events' not in drive:
                continue
            for play in drive['events']:
                event.append({'quarter': quarter.get('sequence'),
                              'wall': play.get('wall_clock'), 
                              'clock': play.get('clock'),
                              'desc': play.get('description'),
                              'play_id': play.get('reference')})
                
    return pd.DataFrame(event)

# Change game time to 60 - (and take care of quarters)

def game_time(time, quarter):
    # Change to float
    time = float(time.replace(':',"."))
    time = 60 - ((quarter - 1) * 15) - (15 - time)
    return time


cow_eag_df = json_to_df(cow_eag_json)
cow_eag_df['clock'] = cow_eag_df.apply(lambda x: x['clock'].zfill(5), axis = 1) 
cow_eag_df['game_time'] = cow_eag_df.apply(lambda x: game_time(x.clock, x.quarter), axis = 1)

pfr_cow_eag = pd.read_csv('input/game_1_mod.csv')
# Just append the PFR prob and andrew times
cow_eag_df['pfr'] = pfr_cow_eag['Win%']
cow_eag_df['andrew'] = pfr_cow_eag['andrew']
cow_eag_df.to_csv('output/cow_eag.csv')

eag_sai_df = json_to_df(eag_sai_json)
eag_sai_df['clock'] = eag_sai_df.apply(lambda x: x['clock'].zfill(5), axis = 1) 
eag_sai_df['game_time'] = eag_sai_df.apply(lambda x: game_time(x.clock, x.quarter), axis = 1)

pfr_eag_sai = pd.read_csv('input/game_2_mod.csv')
eag_sai_df['pfr'] = pfr_eag_sai['Win%']
eag_sai_df['andrew'] = pfr_eag_sai['andrew']
eag_sai_df.to_csv('output/eag_sai.csv')
