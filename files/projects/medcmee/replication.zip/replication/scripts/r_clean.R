  rm(list = ls())
  
  library(nflscrapR)
  library(tidyverse)
  library(parsedate)
  library(openxlsx)
  library(lubridate)
  library(httr)
  library(jsonlite)
  library(stringr)
  library(gridExtra)
  library(imputeTS)
  library(Rfast)
  library(latex2exp)
  library(reshape2)
  options(stringsAsFactors = FALSE)
  
  
  # Read task data
  
  task = read_csv('input/20140131 Experiment Data Revised.csv')
  
  # Input the times that were entered on paper
  task$dictator_created_at[task$paper == 1] = 0.854166666666667 
  
  # Check for NA
  check_NA <- task %>% 
    select_if(function(x) any(is.na(x))) %>% 
    summarise_each(~(sum(is.na(.))))
  
  # sub 203, 205, 217 didn't answer their last questions. We drop those obs
  task$subject_id[is.na(task$level_happiness)]
  
  task <- task %>%
    drop_na(level_happiness)
  
  
  # Adjust happiness, we do this here for plotting
  task <- task %>%
    mutate(hap_adj = level_happiness + 1) # non-paper responses were from 0 - 6
  # Paper were 1 = 7, adjust them back
  task$hap_adj[task$paper == 1] = task$hap_adj[task$paper == 1] - 1
  # Check
  max(task$hap_adj)
  min(task$hap_adj)
  
  
  # takes as input 2 times t1, t2
  # game_list is a list of information
  # events is the dataframe of game_events
  # sid is subject id
  game_events <- function(t1, t2, game_list, events, sub_id) {
    
    game_num = game_list$game_num
    
    
    # Create all the team-wise events
    # split this up for game 1 and game 2
    # its lazy but it works
    if (game_num == 1) {
      tmp = events %>% 
        filter(wall > t1 & wall <= t2) %>%
        mutate(eagles_game1_fmb = ifelse(posteam == 'PHI', fumble_lost, 0), # use fumble_lost over fumbles because fumbles contains fubmle recovered
               cowboys_fmb = ifelse(posteam == 'DAL', fumble_lost, 0),
               eagles_game1_int = ifelse(posteam == 'PHI', interception, 0),
               cowboys_int = ifelse(posteam == 'DAL', interception, 0),
               eagles_game1_fg = ifelse(posteam == 'PHI', field_goal_result_made, 0),
               cowboys_fg = ifelse(posteam == 'DAL', field_goal_result_made, 0),
               eagles_game1_fg_miss = 0, # no missed fg in game 1
               cowboys_fg_miss = 0,
               eagles_game1_td = td_team_PHI,
               cowboys_td = td_team_DAL,
               eagles_game1_yards = ifelse(posteam == 'PHI', yards_gained, 0),
               cowboys_yards = ifelse(posteam == 'DAL', yards_gained, 0), #game 2
               eagles_game1_ffd = ifelse(posteam == 'PHI', fourth_down_failed, 0),
               cowboys_ffd = ifelse(posteam == 'DAL', fourth_down_failed, 0), #game 2
               eagles_game2_fmb = 0,
               saints_fmb = 0,
               eagles_game2_int = 0,
               saints_int = 0,
               eagles_game2_fg = 0,
               saints_fg = 0,
               eagles_game2_fg_miss = 0,
               saints_fg_miss = 0,
               eagles_game2_td = 0,
               saints_td = 0,
               eagles_game2_yards =0,
               saints_yards = 0, 
               eagles_game2_ffd =0,
               saints_ffd = 0, 
               num_pass = play_type_pass,
               num_run = play_type_run,
               eagles_game1_score = total_away_score,
               cowboys_score = total_home_score, 
               eagles_game2_score =0,
               saints_score = 0,
               pfr = 100 - pfr, # put as eagles chance of winning (pfr is for home team)
               wp = away_wp * 100) # eagles are the away team in game 1
    } else {
      tmp = events %>% 
        filter(wall > t1 & wall <= t2) %>%
        mutate(eagles_game1_fmb = 0,
               cowboys_fmb = 0,
               eagles_game1_int = 0,
               cowboys_int = 0,
               eagles_game1_fg = 0,
               cowboys_fg = 0,
               eagles_game1_fg_miss = 0,
               cowboys_fg_miss = 0,
               eagles_game1_td = 0,
               cowboys_td =0,
               eagles_game1_yards =0,
               cowboys_yards = 0,
               eagles_game1_ffd =0,
               cowboys_ffd = 0,       #game 2
               eagles_game2_fmb = ifelse(posteam == 'PHI', fumble_lost, 0),
               saints_fmb = ifelse(posteam == 'NO', fumble_lost, 0),
               eagles_game2_int = ifelse(posteam == 'PHI', interception, 0),
               saints_int = ifelse(posteam == 'NO', interception, 0),
               eagles_game2_fg = ifelse(posteam == 'PHI', field_goal_result_made, 0),
               saints_fg = ifelse(posteam == 'NO', field_goal_result_made, 0),
               eagles_game2_fg_miss = ifelse(posteam == 'PHI', field_goal_result_missed, 0),
               saints_fg_miss = ifelse(posteam == 'NO', field_goal_result_missed, 0),
               eagles_game2_td = td_team_PHI,
               saints_td = td_team_NO,
               eagles_game2_yards = ifelse(posteam == 'PHI', yards_gained, 0),
               saints_yards = ifelse(posteam == 'NO', yards_gained, 0), 
               eagles_game2_ffd = ifelse(posteam == 'PHI',fourth_down_failed, 0),
               saints_ffd = ifelse(posteam == 'NO', fourth_down_failed, 0),
               num_pass = play_type_pass,
               num_run = play_type_run,
               eagles_game1_score = 0,
               cowboys_score =0, 
               eagles_game2_score =total_home_score,
               saints_score = total_away_score,
               pfr = pfr,
               wp = home_wp * 100) # eagles are home team in game 2
    }
    
    # For situations where the times don't return any data, throw a Null and catch later
    if (nrow(tmp) == 0) {
      return()
    } else {
      out = tmp %>%
        summarize(sid = sub_id,
                  time = max(wall,  na.rm = TRUE),
                  and_time = max(andrew, na.rm = TRUE),
                  comm_game_time = max(comm_game_time, na.rm= TRUE),
                  ent_game_time = min(game_time, na.rm = TRUE), # min because game_time returns from 60 to 0
                  eagles_game1_fmb = sum(eagles_game1_fmb, na.rm = TRUE),
                  cowboys_fmb = sum(cowboys_fmb, na.rm = TRUE),
                  eagles_game1_int = sum(eagles_game1_int, na.rm = TRUE),
                  cowboys_int = sum(cowboys_int, na.rm = TRUE),
                  eagles_game1_fg = sum(eagles_game1_fg, na.rm = TRUE),
                  cowboys_fg = sum(cowboys_fg, na.rm = TRUE),
                  eagles_game1_fg_miss = sum(eagles_game1_fg_miss, na.rm = TRUE),
                  cowboys_fg_miss = sum(cowboys_fg_miss, na.rm = TRUE),
                  eagles_game1_td = sum(eagles_game1_td, na.rm = TRUE),
                  cowboys_td = sum(cowboys_td, na.rm = TRUE),
                  eagles_game1_yards = sum(eagles_game1_yards, na.rm = TRUE),
                  cowboys_yards = sum(cowboys_yards, na.rm = TRUE), 
                  eagles_game1_ffd = sum(eagles_game1_ffd, na.rm = TRUE),
                  cowboys_ffd = sum(cowboys_ffd, na.rm = TRUE), #game 2
                  eagles_game2_fmb = sum(eagles_game2_fmb, na.rm = TRUE),
                  saints_fmb = sum(saints_fmb, na.rm = TRUE),
                  eagles_game2_int = sum(eagles_game2_int, na.rm = TRUE),
                  saints_int = sum(saints_int, na.rm = TRUE),
                  eagles_game2_fg = sum(eagles_game2_fg, na.rm = TRUE),
                  saints_fg = sum(saints_fg, na.rm = TRUE),
                  eagles_game2_fg_miss = sum(eagles_game2_fg_miss, na.rm = TRUE),
                  saints_fg_miss = sum(saints_fg_miss, na.rm = TRUE),
                  eagles_game2_td = sum(eagles_game2_td, na.rm = TRUE),
                  saints_td = sum(saints_td, na.rm = TRUE),
                  eagles_game2_yards = sum(eagles_game2_yards, na.rm = TRUE),
                  saints_yards = sum(saints_yards, na.rm = TRUE),
                  eagles_game2_ffd = sum(eagles_game2_ffd, na.rm = TRUE),
                  saints_ffd = sum(eagles_game2_ffd, na.rm = TRUE),
                  num_pass = sum(num_pass, na.rm = TRUE),
                  num_run = sum(num_run, na.rm = TRUE),
                  eagles_game1_score = last(eagles_game1_score),
                  cowboys_score = last(cowboys_score),
                  eagles_game2_score = last(eagles_game2_score),
                  saints_score = last(saints_score),
                  pfr = last(pfr), 
                  wp = last(wp),
                  avg_pfr = mean(pfr),
                  avg_wp = mean(wp),
                  last_drive = last(drive),
                  quarter = last(quarter.x))
    }
    
    return(out)
  }
  
  
  
  
  
  
  # game events obs when where there are no actual game events
  # for example, the tasks before the game starts and one or two
  # obs for after the game is finished

  
  game_events_blank <- function(add_list) {
    
    
    out = tibble(sid = add_list$sid,
                 time = add_list$time,
                 and_time = add_list$and_time,
                 comm_game_time = 60,
                 ent_game_time = add_list$game_time,
                 eagles_game1_fmb = 0,
                 cowboys_fmb = 0,
                 eagles_game1_int = 0,
                 cowboys_int = 0,
                 eagles_game1_fg = 0,
                 cowboys_fg = 0,
                 eagles_game1_fg_miss = 0,
                 cowboys_fg_miss = 0,
                 eagles_game1_td = 0,
                 cowboys_td = 0,
                 eagles_game1_yards =0,
                 cowboys_yards = 0,
                 eagles_game1_ffd =0,
                 cowboys_ffd = 0,#game 2
                 eagles_game2_fmb = 0,
                 saints_fmb = 0,
                 eagles_game2_int = 0,
                 saints_int = 0,
                 eagles_game2_fg = 0,
                 saints_fg = 0,
                 eagles_game2_fg_miss = 0,
                 saints_fg_miss = 0,
                 eagles_game2_td = 0,
                 saints_td = 0,
                 eagles_game2_yards =0,
                 saints_yards = 0,
                 eagles_game2_ffd =0,
                 saints_ffd = 0,
                 num_pass = 0,
                 num_run = 0,
                 eagles_game1_score = 0,
                 cowboys_score =0,
                 eagles_game2_score = add_list$eagles_game2_score,
                 saints_score =add_list$saints_score,
                 pfr = add_list$pfr, 
                 wp = add_list$wp, 
                 last_drive = 1,
                 quarter = 1)
    
    return(out)
    
  }
  
  
  
  
  
  
  # Compute game events for a subject id
  
  # sub_id is subject id
  # events is the dataframe of game_events
  # game_list is a list of information
  
  game_events_sid <- function(sub_id, events, game_list) {
    
    # Excel dates have been time only. This add date information
    base_day = game_list$base_day
    
    # Dataframe for sub id
    sub_id_tibble <- task %>% 
      filter(subject_id == sub_id) 
    
    # First and last times to check
    first_time = events$wall[1]
    last_time = tail(events$wall, 1)
    
    # Time under consideration
    times =sub_id_tibble$dictator_created_at
  
    
    # List of things to pass to game_events_blank for before game events
    first_list = list(time = convertToDateTime(base_day + game_list$first_time), 
                      and_time = events$andrew[1],
                      game_time = 60, 
                      pfr = events$pfr[1],
                      wp = 50,
                      eagles_game2_score = 0,
                      saints_score = 0,
                      sid = sub_id,
                      game_num = game_list$game_num)
    
    
    # before game starts
    if (convertToDateTime(base_day + times[1]) < first_time) {
      out = game_events_blank(first_list)
    } else {
      # subjects 107, 108, 112, 116, 117, 120, 121, 122, 123, 124, 126, 127
      # don't answer first on paper. Their first time is after game has started
      # so we don't want a 'blank' entry
      conv_default = convertToDateTime(base_day + game_list$first_time)
      conv_first = convertToDateTime(base_day + times[1])
      out = game_events(conv_default, conv_first,
                        game_list, events, sub_id)
    }
    
    
    for (i in 2:length(times)) {
      
      
      prev_time = convertToDateTime(base_day + times[i-1])
      cur_time = convertToDateTime(base_day + times[i])
      
      tmp = game_events(prev_time, cur_time, game_list, events, sub_id)
      
      # Catch out error from game_events if times don't return anything
      if (is.null(tmp)) {
        # Set row to previous row
        tmp = out[(i-1),]
        # and all game events to 0 (but not scores), did it like this because it is much safer than
        # int indexing. Used dput(names(tmp))
        zero_cols = c("eagles_game1_fmb", "cowboys_fmb", "eagles_game1_int", "cowboys_int", 
                      "eagles_game1_fg", "cowboys_fg", "eagles_game1_fg_miss", "cowboys_fg_miss", 
                      "eagles_game1_td", "cowboys_td", "eagles_game1_yards", "cowboys_yards", 
                      "eagles_game1_ffd", "cowboys_ffd", "eagles_game2_fmb", "saints_fmb", 
                      "eagles_game2_int", "saints_int", "eagles_game2_fg", "saints_fg", 
                      "eagles_game2_fg_miss", "saints_fg_miss", "eagles_game2_td", 
                      "saints_td", "eagles_game2_yards", "saints_yards", "eagles_game2_ffd", 
                      "saints_ffd", "num_pass", "num_run")
        tmp[zero_cols] = 0 
      }
      
      out = bind_rows(out, tmp)
    }
    
    return(out)
  }
  
  
  
  
  
  
  generate_game_events <- function(scrape, game_list) {
    
    if (scrape) {
      # Find list of games during that week for game_id
      week_games <- scrape_game_ids(2013, type = game_list$type, weeks = game_list$weeks)
      
      # Fetch play_by_play
      my_game <- week_games %>%
        filter(home_team == game_list$home_team) %>%
        pull(game_id) %>%
        scrape_json_play_by_play()
      
      # Rename columns for merge
      my_game <- my_game %>%
        rename('quarter' = 'qtr', 'clock' = 'time')
      
      # Change play_id to numeric
      my_game$play_id <- as.numeric(my_game$play_id)
      
      # Import data from py_data
      py_data <- read_csv(str_c("output/", game_list$py_data))
      #Clock is parsed as HMS. Convert to chr and drop :00
      py_data$clock <- as.character(py_data$clock)
      py_data$clock <- unlist(map(py_data$clock, function(x) substr(x,1, nchar(x)-3)))
      
      # Merge datasets together
      events = py_data %>% left_join(my_game, by = c('play_id'))
      
      write_csv(events, str_c("output/g", game_list$game_num, "_ev.csv"))
    } else {
      events <- read_csv(str_c("output/g", game_list$game_num, "_ev.csv"))       
    }
    
    # Andy times only have 70 entries (as opposed to PFR which has ~160)
    # Create a dataframe with the Andy commercial times, will be 
    # used in plotting and returned
    ind = !is.na(events$andrew)
    
    matched_times = tibble(game_time = events$game_time[ind], 
                           comm_time = events$andrew[ind], 
                           pfr = events$pfr[ind],
                           home_score = events$total_home_score[ind],
                           away_score = events$total_away_score[ind])
    
    
    # Andrew times have a bunch of NA's (they are only recorded for specific times)
    # We want to fill up these NA
    # the direction down turns c(1, NA, 2) into c(1,1,2)
    # In this sense we will match the commercial break that occurs before the time we are matching on
    # We want to do this because subjects tended to answer questions at the start of a commercial break
    # So if they were to be recorded slightly after a commercial break, we would want to match the "previous"
    # break, as opposed to the "next" break
    comm_game_time <- rep(NA, length(events$game_time))
    comm_game_time[!is.na(events$andrew)] <- events$game_time[!is.na(events$andrew)]
    
    events['comm_game_time'] = comm_game_time
    events <- events %>% 
      fill(comm_game_time, .direction = "down")
    
    
    # We will also down fill the andrew times (which are in excel format)
    events <- events %>%
      fill(andrew, .direction ="down")
  
    # Drives + quarter changes
    events$drive[events$quarter.x > 1] <- events$drive[events$quarter.x > 1]  + 1
    events$drive[events$quarter.x > 3] <- events$drive[events$quarter.x > 3]  + 1
    
    
  
    # Do some game specific changes
    if (game_list$game_num == 1) {
      #Add in a couple of walltimes using Andrew's hand written times (other times are not important and not recorded)
      events$wall[83] = parse_iso_8601("2013-12-30T02:51:00+00:00") # 9:51:00 PM
      events$wall[153] = parse_iso_8601("2013-12-30T04:09:50+00:00") # 11:11:00 PM
    }
    
    # Add dummies for events
    events <- fastDummies::dummy_cols(events, select_columns = c('play_type', 'field_goal_result', 'td_team'))
    # Some dummies have NA instead of 0's
    events$field_goal_result_made[is.na(events$field_goal_result_made)] <- 0
    if (game_list$game_num == 1) {
      events$td_team_PHI[is.na(events$td_team_PHI)] <- 0
      events$td_team_DAL[is.na(events$td_team_DAL)] <- 0
    } else {
      events$td_team_PHI[is.na(events$td_team_PHI)] <- 0
      events$td_team_NO[is.na(events$td_team_NO)] <- 0
    }
    
    
    # Unique subject ids
    if (game_list$game_num == 1) {
      ids_cons = unique(task$subject_id[task$subject_id < 200])
    } else {
      ids_cons = unique(task$subject_id[task$subject_id >= 200])
    }
    num_ids = length(unique(ids_cons))
    
    out = list()
    for (i in 1:num_ids) {
      id = ids_cons[i]
      out[[i]] = game_events_sid(id, events, game_list)
    }
    
    out = bind_rows(out)
    
    return(list("task" = out, "events" = events, "graph_times" = matched_times))
  }
  
  
  
  
  
  
  
  
  
  
  
  #### 
  
  # game lists to pass to generate_game_events and lower level functions
  
  # default time is 0.854166666666667 = 8:30
  # 41637 = 29-12-2013
  game1 <- list(game_num = 1, type = "reg", weeks = 17, home_team = "DAL", away_team = "DAL", 
                first_time = 0.854166666666667, base_day = 41637, py_data = 'cow_eag.csv')
  
  # default time is 0.843055555555556 = 8:14
  # 41643 = 04-01-2014
  game2 <- list(game_num = 2, type = "post", weeks = 1, home_team = "PHI", away_team = "NO", 
                first_time = 0.843055555555556, base_day = 41643, py_data = 'eag_sai.csv')
  
  
  g1 = generate_game_events(FALSE, game1)
  g2 = generate_game_events(FALSE, game2)
  
  game_combined = bind_rows(g1$task, g2$task)
  
  
  
  
  
  
  
  
  
  
  
  ### Sanity checks
  drop_obs_new = game_combined %>% group_by(sid) %>% summarize(n())
  drop_obs_old = task %>% group_by(subject_id) %>% summarize(n())
  
  sum(drop_obs_new[,2] - drop_obs_old[,2]) # if 0 no obs dropped
  
  
  
  
  
  # Merge task and game events
  task_game_events = bind_cols(task, game_combined)
  
  # Any na's in pfr?
  sum(is.na(task_game_events$pfr))

  
  
  
  
  
  ### Merge in subject ID data
  subject_id_data <- read_csv('input/subjects_mod.csv')
  
  subject_id_data$subject_id = (subject_id_data$Session * 100) + subject_id_data$subject_id 
  
  
  full <- task_game_events %>% left_join(subject_id_data, by = c('subject_id'))
  # Check for NA
  full %>% 
    select_if(function(x) any(is.na(x))) %>% 
    summarise_each(~(sum(is.na(.)))) -> extra_NA
  
  write_csv(full, "./output/r_output.csv", na = "")
  
  
  
  
  
  
  
  
  
  ## Graphs
  # We don't want to plot at all ~160 pfr times
  # So we will only plot at the commercial times (Andrew's times)
  # which have at least 5 observations in a game
  
  # This is the function which round to the closest of the 
  # greater than 5 commercials
  my_round <- function(my_numer, and_time_sub) {
    
    and_index = which.min(abs(and_time_sub$and_time - my_numer))
    
    return(and_index)
  }
  
  
  # Produce the happiness and spw matrices for each indiv in each 
  # game
  
  # Inter - 0 to only input the times with answers
  #         1 for interpolation
  #         2 for forward fill 
  # Match_num is number of obs to agg for, eg 5 means greater than
  # obs only
  graph_mat <- function(game_num, graph_times, inter= 2, match_num = 5) {
    
    
    g_task <- full %>% filter(Session.y == game_num)
    
    # tab function in stata for and_time
    and_time_counts <- g_task %>%
      group_by(and_time) %>%
      summarise(n = n()) %>%
      mutate(totalN = (cumsum(n)),
             percent = round((n / sum(n)), 3),
             cumpercent = round(cumsum(freq = n / sum(n)), 3))
    
    # Merge with graph_times
    and_time_counts <- left_join(and_time_counts, graph_times , by = c("and_time" = "comm_time"))
    
    and_time_sub = and_time_counts %>% 
      filter(n >= match_num) %>%
      select(and_time,
             game_time, 
             pfr, 
             home_score, 
             away_score)
    
    g_task$rounded = sapply(g_task$and_time, function(x) my_round(x, and_time_sub))
    
    
  
    sids = unique(g_task$subject_id)
    hap_list = list()
    spw_list = list()
    
    num_event = max(g_task$rounded)
    
    
    for (i in 1:length(sids)) {
      
      sub_id_tibble <- g_task %>% 
        filter(subject_id == sids[i]) 
      
      hap = sub_id_tibble$hap_adj
      spw = sub_id_tibble$likeliness_winning
      
      hap2 = rep(NA, num_event)
      spw2 = rep(NA, num_event)
      
      row_ind = sub_id_tibble$rounded
      hap2[row_ind] = hap
      spw2[row_ind] = spw
      
      if (inter == 1) {
        hap_list[[i]] = na.interpolation(hap2)
        spw_list[[i]] = na.interpolation(spw2)
      } else if (inter == 2) {
        # Use fill function, means we need to convert first to a tibble then back to a vector
        hap_list[[i]] = fill(tibble(hap2), hap2, .direction = c("down")) %>% data.matrix()
        spw_list[[i]] = fill(tibble(spw2), spw2, .direction = c("down")) %>% data.matrix()
      } else {
        hap_list[[i]] = hap2
        spw_list[[i]] = spw2
      }
    }
    
    hap_mat = t(do.call(cbind, hap_list)) # rbind was doing funny things (i think due to NA's)
    spw_mat = t(do.call(cbind, spw_list))
    
    return(list("hap_mat" = hap_mat, "spw_mat" = spw_mat, "and_time_sub" = and_time_sub, 'sids' = sids))
  }
  
  
  
  
  
  # Use inbuilt ttesting for CI's
  # This is for differences in two mats
  diff_ttest <- function(mat1, mat2) {
    
    # Instead of apply use a loop so we can do a catch for constants
    num_time = dim(mat1)[2] 
    avg = vector(mode="numeric", length=num_time)
    eag_avg = vector(mode="numeric", length=num_time)
    oth_avg = vector(mode="numeric", length=num_time)
    lo = vector(mode="numeric", length=num_time)
    up = vector(mode="numeric", length=num_time)
    for (i in 1:num_time) {
      ttest = t.test(mat1[,i],mat2[,i] )
      avg[i] = ttest$estimate[1] - ttest$estimate[2]
      eag_avg[i] = ttest$estimate[1]
      oth_avg[i] = ttest$estimate[2]
      lo[i] = ttest$conf.int[1]
      up[i]= ttest$conf.int[2]
    }
    
    tib = tibble(avg, eag_avg, oth_avg, lo, up)
    
    return(tib)
  }
  
  
  
  # Standard ttest for a mat, name gives names to tib columns
  ttest <- function(mat, name) {
    
    # Instead of apply use a loop so we can do a catch for constants
    num_time = dim(mat)[2] 
    avg = vector(mode="numeric", length=num_time)
    lo = vector(mode="numeric", length=num_time)
    up = vector(mode="numeric", length=num_time)
    for (i in 1:dim(mat)[2]) {
      vec = mat[,i]
      if (abs(max(vec, na.rm = TRUE) - min(vec, na.rm = TRUE)) < 0.001) {
        avg[i] = mean(vec)
        lo[i] = avg[i]
        up[i] = avg[i]
      } else {
        ttest = t.test(mat[,i])
        avg[i] = ttest$estimate
        lo[i] = ttest$conf.int[1]
        up[i]= ttest$conf.int[2]
      }
    }
    
    tib = tibble(avg, lo, up)
    
    names(tib) <- c(paste0(name, "_avg"),
                    paste0(name, "_lo"),
                    paste0(name, "_up"))
    
    return(tib)
  }
  
  
  
  
  
  
  
  
  
  create_graph <- function(hap_mat, spw_mat, and_time_sub, game_num,match_num) {
  
  
    game_sub = subject_id_data %>% filter(Session ==game_num)
  
  
    if (game_num == 1) {
      other_team = 17 # Cowboys
      and_time_sub$score_diff = and_time_sub$away_score - and_time_sub$home_score 
      other_team_name = "Cowboys"
      and_time_sub$pfr = 100 - and_time_sub$pfr
    } else {
      other_team = 27 # Saints
      and_time_sub$score_diff = and_time_sub$home_score - and_time_sub$away_score 
      other_team_name = "Saints"
    }
  
    # Happiness
    eagles_hap = hap_mat[game_sub$favored_team == 19, ]
    other_hap = hap_mat[game_sub$favored_team == other_team, ]
  
    hap_diff = diff_ttest(eagles_hap, other_hap)
  
    
    # SPW
    eagles_spw = spw_mat[game_sub$favored_team == 19, ]
    other_spw = 100 - spw_mat[game_sub$favored_team == other_team, ]
    # Combined
    comb_mat <- rbind(eagles_spw,other_spw)
    
    
    eagles = ttest(eagles_spw, "eagles")
    other = ttest(other_spw, "other")
    comb = ttest(comb_mat, "comb")
    
    spw = bind_cols(eagles,other,comb)
    
    
    graph_df = bind_cols(hap_diff, spw, and_time_sub)
  
    
    
    # Happ_diff
    hap_diff_graph <- graph_df %>%
      ggplot() +
      geom_line(aes(x = 60 - game_time, y = avg ),size = 1.25) +  
      geom_ribbon(aes(x = 60 - game_time, ymin =lo, ymax =up), alpha=0.3) +
      geom_hline(yintercept=0, linetype="dashed") + 
      #ylim(-2.2, 1.2) +
      labs(x="Game Time", y=unname(TeX("$\\Delta$ Happiness"))) +
      theme(axis.title.x = element_blank(),
            axis.text.x = element_blank(), 
            axis.title.y = element_text(size = 16),
            axis.text.y= element_text(size = 12))
  
    
    score <- graph_df %>%
      ggplot() +
      geom_line(aes(x = 60 - game_time, y = score_diff), size = 1.25) +
      geom_hline(yintercept=0, linetype="dashed") +
      labs(x="Game Time", y=unname(TeX("$\\Delta$ Score"))) +
      theme(        axis.title.x = element_text(size = 16),
                    axis.text.x = element_text(size = 12), 
                    axis.title.y = element_text(size = 16),
                    axis.text.y= element_text(size = 12))
    
    
    combined <- grid.arrange(hap_diff_graph, score,  nrow =2)
    
    ggsave(combined, file=str_c("output/r_graphs/g", game_num, "_hap_score.jpg"))
    ggsave(combined, file=str_c("output/r_graphs/g", game_num, "_hap_score.eps"), device=cairo_ps)
    
    
    # This is because if I want to pass a string for values in scale_linetype_manual it bricks
    # Probably could fix using eval or parse or something
    my_values =  c("solid", "dashed", "dotted")
    names(my_values) = c("PFR", "Eagles", other_team_name )
    
    if (game_num == 1) {
      leg_pos = c(0.1, 0.9)
    } else {
      leg_pos = c(0.1, 0.15)
    }
    
    # SPW
    spw_graph <- graph_df %>%
      ggplot() +
      #geom_line(aes(x = 60 - game_time, y = team_avg ),size = 1) +
      geom_line(aes(x = 60 - game_time, y = eagles_avg, linetype = "Eagles" ),size = 1.25) +
      geom_ribbon(aes(x = 60 - game_time, ymin =eagles_lo, ymax =eagles_up), alpha=0.3) +
      geom_line(aes(x = 60 - game_time, y = other_avg, linetype = other_team_name),size = 1.25) +
      geom_ribbon(aes(x = 60 - game_time, ymin =other_lo, ymax =other_up), alpha=0.5) +
      geom_line(aes(x = 60 - game_time, y = pfr, linetype = "PFR" ),size = 1.25) +
      geom_hline(yintercept=50, linetype="dashed") +
      scale_linetype_manual(name = "", values = my_values) +
      labs(x="Game Time", y="Probability") +
      theme(legend.position=leg_pos,
            legend.background = element_blank(),
            legend.text = element_text(size = 14),
            axis.title.x = element_text(size = 16),
            axis.text.x = element_text(size = 12), 
            axis.title.y = element_text(size = 16),
            axis.text.y= element_text(size = 12))
    
    ggsave(spw_graph, file=str_c("output/r_graphs/g", game_num, "_probs.jpg"))
    ggsave(spw_graph, file=str_c("output/r_graphs/g", game_num, "_probs.eps"), device=cairo_ps)
      
  
  }
  
  
  
  
  
  
  
  
  all_graph <- function(game_num, match_num = 5) {
    
    if (game_num == 1) {
      graph_times = g1$graph_times
    } else {
      graph_times = g2$graph_times
    }
  
    mat = graph_mat(game_num, graph_times, match_num = match_num) 
    
    
    hap_mat = mat$hap_mat
    spw_mat = mat$spw_mat
    and_time_sub = mat$and_time_sub
    
    create_graph(hap_mat, spw_mat, and_time_sub, game_num, match_num)
  }
  
  all_graph(1, match_num = 4)
  all_graph(2, match_num = 4)
  
  
  
  
  
  
  
  do_peers <- function(full, game_num) {
    
    if (game_num == 1) {
      gt = g1$graph_times
    } else {
      gt = g2$graph_times
    }
    mat = graph_mat(game_num, gt)  
  
    hap_mat <- mat$hap_mat
    
    game_df <- full %>% 
      filter(Session.x == game_num)
    uni_ids <- unique(game_df$subject_id)
    
    tmp <-game_df %>% 
      filter(favored_team == 19)
    
    eagles_fan <- unique(tmp$subject_id)
    eagles_ind <- uni_ids %in% eagles_fan
  
    sids <- dim(hap_mat)[1]
    comm_T <- dim(hap_mat)[2]
  
    all_peers <- matrix(0,sids, comm_T)
    team_peers <- matrix(0,sids, comm_T)
    for (i in 1:sids) {
      # eagles fan
      if (eagles_ind[i]) {
        tmp = eagles_ind
        
      } else {
        tmp = !eagles_ind
      }
      tmp[i] = FALSE
      team_peers[i,] <- colMeans(hap_mat[tmp, ], na.rm=TRUE)
      
      all_peers[i,] <- colMeans(hap_mat[-i, ], na.rm=TRUE)
    }

    rownames(all_peers) <- mat$sids
    colnames(all_peers) <- mat$and_time_sub$and_time
    rownames(team_peers) <- mat$sids
    colnames(team_peers) <- mat$and_time_sub$and_time
    # indiv happiness graphs
    
    all_melted <- melt(all_peers)
    names(all_melted) <-  c("subject_id", "and_time_dup", "all_peers")
    all_melted$event <- sapply(all_melted$and_time, function(x) my_round(x, mat$and_time_sub))
    
    team_melted <- melt(team_peers)
    names(team_melted) <-  c("subject_id", "and_time_dup", "team_peers")
    team_melted$event <- sapply(team_melted$and_time, function(x) my_round(x, mat$and_time_sub))
    
    full$event = sapply(full$and_time, function(x) my_round(x, mat$and_time_sub))
    
    melted <- left_join(all_melted, team_melted,by = c("subject_id","event"))

    new_full <- left_join(full, melted, by = c("subject_id","event") )
    
    return(new_full)
  }
  
  n_full <- do_peers(full, 1)
  n_full <- do_peers(n_full, 2)
  
  
  n_full$all_peers <- n_full$all_peers.x
  n_full$all_peers[is.na(n_full$all_peers)] <- n_full$all_peers.y[!is.na(n_full$all_peers.y)]
  
  n_full$team_peers <- n_full$team_peers.x
  n_full$team_peers[is.na(n_full$team_peers)] <- n_full$team_peers.y[!is.na(n_full$team_peers.y)]
  
  
  write_csv(n_full, "./output/r_output.csv", na = "")
  
  
  
  
  g1_indiv <- full %>% 
    filter(Session.x == 1) %>%
    ggplot() +
    geom_line(mapping = aes(x = 60 - comm_game_time, y = hap_adj)) +
    facet_wrap(~ subject_id, ncol = 5) +
    labs(x="Game Time", y="Happiness") +
    theme(axis.title.x = element_text(size = 16),
          axis.text.x = element_text(size = 10), 
          axis.title.y = element_text(size = 16),
          axis.text.y= element_text(size = 8))
  ggsave(g1_indiv, file="output/r_graphs/g1_indiv.eps", width = 5,
         height = 6, device=cairo_ps)
  
  g2_indiv <- full %>% 
    filter(Session.x == 2) %>%
    ggplot() +
    geom_line(mapping = aes(x = 60 - comm_game_time, y = hap_adj)) +
    facet_wrap(~ subject_id, ncol = 5) +
    labs(x="Game Time", y="Happiness") +
    theme(axis.title.x = element_text(size = 16),
          axis.text.x = element_text(size = 10), 
          axis.title.y = element_text(size = 16),
          axis.text.y= element_text(size = 8))
  ggsave(g2_indiv, file="output/r_graphs/g2_indiv.eps", width = 5,
         height = 6, device=cairo_ps)
